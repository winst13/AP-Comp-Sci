import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;


public class Mho 
{
	private int x;
	private int y;
	private final int WIDTH_OF_MHO = 30;
	private final int HEIGHT_OF_MHO = 30;
	private final int SEPARATION_OF_MHO = 10;
	
	/**
	 * This is the constructor for an Mho.  It only
	 * has two arguments, the x and y coordinates
	 * @param myx
	 * @param myy
	 */
	public Mho(int myx, int myy)
	{
		x = myx;
		y = myy;
	}
	
	/**
	 * This method paints an individual Mho.  It is possible
	 * to change this to display anything that will fit inside
	 * a single cell
	 * @param g
	 */
	public void paintMho(Graphics g)
	{
		g.setColor(Color.RED);
		g.drawOval(x*Hivolt.SIZE_OF_CELL+SEPARATION_OF_MHO, 
				y*Hivolt.SIZE_OF_CELL+SEPARATION_OF_MHO+GridLines.SIZE_OF_TOP_BAR, 
				WIDTH_OF_MHO, HEIGHT_OF_MHO);
	}
	
	/**
	 * This method adds an Mho to an ArrayList of Mhos
	 * @param listofmhos
	 * @return the exact same as listofmhos, except with a
	 * new Mho at the end
	 */
	public static ArrayList<Mho> addRandomMho(ArrayList<Mho> listofmhos)
	{
		//Creates a new Mho with random coordinates
		Random z = new Random();
		int x = z.nextInt(Hivolt.COLUMNS_IN_GRID-2)+1;
		int y = z.nextInt(Hivolt.ROWS_IN_GRID-2)+1;
		Mho e = new Mho(x,y);
		
		//Test if this Mho is on top of a fence
		boolean equals = false;
		for (int i = 0; i < Hivolt.interior.listoffences.size(); i++)
		{
			if (e.equals(Hivolt.interior.listoffences.get(i)))
			{
				equals = true;
			}
		}

		//Tests if this Mho is on top of another Mho
		for (int i = 0; i < Hivolt.NUMBER_OF_MHOS; i++)
		{
			for (int j = 0; j < listofmhos.size(); j++)
			{
				if (e.equals(listofmhos.get(j)))
				{
					equals = true;
				}
			}
		}
		
		//If the Mho is on a fence or another Mho, the method will restart
		if (equals == true)
		{
			addRandomMho(listofmhos);
		}
		//If the Mho was not equal to any other, the new Mho will
		//be added to listofmhos
		else if (equals == false)
		{
			listofmhos.add(e);
		}
		return listofmhos;
	}
	/**
	 * This method makes it possible to compare Mhos to other Mhos
	 * @param m
	 * @return
	 */
	public boolean equals(Mho m)
	{
		boolean equals = false;//When it is not equal, return false
		if (x == m.x && y == m.y)
		{
			equals = true;
		}
		else
		{
			
		}
		return equals;
	}
	
	/**
	 * This method makes it possible to compare an ElectricFence
	 * and a the Mho
	 * @param e
	 * @return
	 */
	public boolean equals (ElectricFence e)
	{
		boolean equals = false;
		if (x == e.getx() && y == e.gety())
		{
			equals = true;
		}
		else
		{
			
		}
		return equals;//Returns true if their coordinates are the same
	}
	
	/**
	 * Gets the x coordinate
	 * @return
	 */
	public int getx()
	{
		return x;
	}
	
	/**
	 * Sets the x coordinate
	 * @param myx
	 */
	public void setx(int myx)
	{
		x = myx;
	}
	
	/**
	 * Gets the y coordinate
	 * @return
	 */
	public int gety()
	{
		return y;
	}
	
	/**
	 * Sets the y coordinate
	 * @param myy
	 */
	public void sety(int myy)
	{
		y = myy;
	}
}
