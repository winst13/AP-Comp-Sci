import java.util.ArrayList;


public class Test 
{
	public static void main(String args[])
	{
		/*ArrayList<ElectricFence> listoffences = new ArrayList<ElectricFence>();
		for (int i = 0; i < 20; i++)
		{
			ArrayList<ElectricFence >newlist = ElectricFence.newRandomFence(listoffences);
			listoffences = newlist;
		}
		for (int i = 0; i < 20; i++)
		{
			System.out.println(i + ":  x = " + listoffences.get(i).xcoordinate);
			System.out.println("y = " + listoffences.get(i).ycoordinate);
		}*/
		System.out.println(fib(6));
	}
	
	public static int fib(int n)
	{
		if (n==1) return 1;
		else if (n==2) return 1;
		else return (fib(n-1)+fib(n-2));
	}
}
