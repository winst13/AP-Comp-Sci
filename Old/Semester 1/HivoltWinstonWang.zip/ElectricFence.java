import java.awt.Color;
import java.awt.Graphics;

public class ElectricFence
{	
	private int xcoordinate;
	private int ycoordinate;
	public static final int NO_OF_FENCES = 20;
	private static final int FENCE_SEPARATION = 10;
	private static final int SIZE_OF_FENCE = 30;
	
	/**
	 * Creates a new ElectricFence with given coordinates
	 * @param myxcoordinate
	 * @param myycoordinate
	 */
	public ElectricFence(int myxcoordinate, int myycoordinate)
	{
		xcoordinate = myxcoordinate;
		ycoordinate = myycoordinate;
	}
	
	/**
	 * Paints a single fence.  This can also be changed
	 * @param g
	 */
	public void paintFence(Graphics g)
	{
		g.setColor(Color.WHITE);
		g.drawRect(this.xcoordinate*Hivolt.SIZE_OF_CELL+FENCE_SEPARATION, 
				this.ycoordinate*Hivolt.SIZE_OF_CELL+FENCE_SEPARATION+GridLines.SIZE_OF_TOP_BAR, 
				SIZE_OF_FENCE, SIZE_OF_FENCE);
	}
	

	/**
	 * Enables program to compare two ElectricFences
	 * @param e
	 * @return
	 */
	public boolean equals(ElectricFence e) 
	{
		boolean equals = false;
		if (e.xcoordinate == xcoordinate && e.ycoordinate == ycoordinate)
		{
				 equals = true;
		}
		return equals;//If result is false, then they are the different.  
		//If result is true, they are equal
	}
	
	/**
	 * Gets the x coordinate
	 * @return
	 */
	public int getx()
	{
		return xcoordinate;
	}
	
	/**
	 * Gets the y coordinate
	 * @return
	 */
	public int gety()
	{
		return ycoordinate;
	}
	
	/**
	 * Sets x coordinate
	 * @param x
	 */
	public void setx(int x)
	{
		xcoordinate = x;
	}
	
	/**
	 * Gets y coordinate
	 * @param y
	 */
	public void sety(int y)
	{
		ycoordinate = y;
	}
}
