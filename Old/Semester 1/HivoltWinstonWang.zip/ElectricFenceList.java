import java.util.ArrayList;
import java.util.Random;


public class ElectricFenceList
{
	public ArrayList<ElectricFence> listoffences;
	
	/**
	 * Constructs an instance of this class
	 */
	public ElectricFenceList()
	{
		listoffences = new ArrayList<ElectricFence>();
	}
	
	/**
	 * This method adds the fences in the perimeter to any
	 * instance of ElectricFenceList
	 * @return
	 */
	public ArrayList<ElectricFence> makePerimeterList()
	{
		for (int i = 0; i < Hivolt.COLUMNS_IN_GRID; i++)
		{
			if (i==0 || i == (Hivolt.COLUMNS_IN_GRID-1))
			{
				for (int j = 0; j < Hivolt.ROWS_IN_GRID; j++)
				{
					ElectricFence e = new ElectricFence(i, j);
					listoffences.add(e);
				}
			}
			else
			{
				ElectricFence e = new ElectricFence(i, 0);
				listoffences.add(e);
				e = new ElectricFence(i, Hivolt.ROWS_IN_GRID-1);
				listoffences.add(e);
			}
		}
		return listoffences;
	}
	
	/**
	 * Adds the fences in the interior to any ElectricFenceList
	 * @return
	 */
	public ArrayList<ElectricFence> makeInteriorList()
	{
		for (int i = 0; i < ElectricFence.NO_OF_FENCES; i++)
		{
			listoffences = newRandomFence(listoffences);
		}
		return listoffences;
	}
	
	/**
	 * Adds a random fence to an ArrayList of ElectricFences
	 * @param listoffences
	 * @return
	 */
	public static ArrayList<ElectricFence> newRandomFence(ArrayList<ElectricFence> listoffences)
	{
		Random r = new Random();
		int x = r.nextInt(Hivolt.COLUMNS_IN_GRID-2)+1;
		int y = r.nextInt(Hivolt.ROWS_IN_GRID-2)+1;
		boolean equal = false;
		ElectricFence e = new ElectricFence(x, y);
		for (int j = 0; j < listoffences.size(); j++)
		{
			if (e.equals(listoffences.get(j)))
			{
				equal = true;
			}
		}
		if (equal == false)
		{
			listoffences.add(e);
		}
		else
		{
			newRandomFence(listoffences);
		}
		x = 0;
		y = 0;
		return listoffences;
	}

}
