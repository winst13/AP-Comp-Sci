import java.util.ArrayList;


public class MhoList 
{
	public ArrayList<Mho> mholist;
	
	/**
	 * This creates a new MhoList.  It automatically
	 * creates an ArrayList with all the Mhos
	 */
	public MhoList()
	{
		mholist = new ArrayList<Mho>();
		for (int i = 0; i < Hivolt.NUMBER_OF_MHOS; i++)
		{
			ArrayList<Mho> newlist = Mho.addRandomMho(mholist);
			mholist = newlist;
		}
	}
}
