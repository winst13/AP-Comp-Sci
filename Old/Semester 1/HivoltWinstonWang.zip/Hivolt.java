import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Hivolt extends JFrame implements KeyListener
{	
	public static final int ROWS_IN_GRID = 12;
	public static final int COLUMNS_IN_GRID = 12;
	public static final int NUMBER_OF_MHOS = 12;
	public static final int NUMBER_OF_FENCES = 20;
	public static final int SIZE_OF_CELL = 50;
	public static ElectricFenceList perimeter;
	public static ElectricFenceList interior;
	public static MhoList mhos;
	
	/**
	 * This is the constructor.  Creating an instance of Hivolt
	 * will draw the game
	 */
	public Hivolt()
	{
		init(ROWS_IN_GRID,COLUMNS_IN_GRID);
	}
	
	/**
	 * This method creates the frame
	 * @param rows
	 * @param columns
	 */
	public void init(int rows, int columns)
	{
		setSize(50*columns, 50*rows+20);
		setBackground(Color.BLACK);
		repaint();
	}
	
	/**
	 * This method paints everything, although everything is encapsulated
	 * in their own classes
	 */
	public void paint(Graphics g)
	{
		//Creates a new grid object
		GridLines grid = new GridLines(ROWS_IN_GRID, COLUMNS_IN_GRID, SIZE_OF_CELL);
		g.setColor(Color.WHITE);
		grid.paint(g);
		//Added a KeyListener in order to detect keystrokes
		addKeyListener(this);
		//Makes a list of ElectricFences for the perimeter only
		perimeter = new ElectricFenceList();
		perimeter.makePerimeterList();
		
		//Paints each fence in perimeter
		for (int i = 0; i < perimeter.listoffences.size(); i++)
		{
			ElectricFence fence = perimeter.listoffences.get(i);
			fence.paintFence(g);
		}
		
		//Makes a list of ElectricFences for the interior only
		interior = new ElectricFenceList();
		interior.makeInteriorList();
		
		//Paints each fence in interior
		for (int i = 0; i < interior.listoffences.size(); i++)
		{
			ElectricFence fence = interior.listoffences.get(i);
			fence.paintFence(g);
			//Commented line of code below prints the list of fences
			//System.out.println(fence.getx()+", "+fence.gety());
		}
		
		//Makes a list of Mhos
		mhos = new MhoList();
		
		//Paints all the Mhos
		for (int i = 0; i < mhos.mholist.size(); i++)
		{
			Mho mho = mhos.mholist.get(i);
			mho.paintMho(g);
		}
		
		//Paint Actor
		
		//
	}

	/**
	 * This method allows the program to move the Actor,
	 * which is an essential part of the project.
	 */
	public void keyTyped(KeyEvent e) 
	{
		
	}

	/**
	 * 
	 */
	public void keyPressed(KeyEvent e) 
	{
		
	}

	/**
	 * 
	 */
	public void keyReleased(KeyEvent e) 
	{
		
	}
}
